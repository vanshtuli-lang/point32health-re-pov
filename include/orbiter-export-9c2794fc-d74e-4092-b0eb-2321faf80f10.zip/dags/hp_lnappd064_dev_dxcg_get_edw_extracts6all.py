"""airflow-legacy-graph: v1
file: hp_lnappd064_dev_dxcg_get_edw_extracts6all.graph.yaml
"""

from airflow.providers.standard.operators.bash import BashOperator
from airflow.sdk import DAG
from include.assets import (
    autosys_conditionlocalhp_lnappd064_dev_dxcg_get_edw_extracts6all,
)
from pathlib import Path
from pendulum import DateTime, Time, Timezone
from pendulum.tz.timezone import FixedTimezone
import datetime

with DAG(
    dag_id="hp_lnappd064_dev_dxcg_get_edw_extracts6all",
    schedule=[autosys_conditionlocalhp_lnappd064_dev_dxcg_get_edw_extracts6all],
    start_date=DateTime(1970, 1, 1, 0, 0, 0),
    catchup=False,
    tags=["airflow-legacy:graph-v1"],
    default_args={"owner": "dxcgusr", "queue": "lnappd064"},
    doc_md=Path(__file__)
    .parent.parent.joinpath(
        "include/hp_lnappd064_dev_dxcg_get_edw_extracts6all/_dag.md"
    )
    .read_text(),
) as dag:
    hp_lnappd064_dev_dxcg_get_edw_extracts6all_task = BashOperator(
        task_id="hp_lnappd064_dev_dxcg_get_edw_extracts6all",
        doc_md=Path(__file__)
        .parent.parent.joinpath(
            "include/hp_lnappd064_dev_dxcg_get_edw_extracts6all/hp_lnappd064_dev_dxcg_get_edw_extracts6all.md"
        )
        .read_text(),
        queue="lnappd064",
        bash_command="source /app/dxcg/DXCG6ALL/scripts/setenv.sh; /app/dxcg/DXCG6ALL/scripts/getEDWextracts devl > /app/dxcg/DXCG6ALL/log/GET_EDW_EXTRACTS6ALL.log 2> /app/dxcg/DXCG6ALL/log/GET_EDW_EXTRACTS6ALL.err",
        doc="Get edw extracts",
        owner="dxcgusr",
    )
