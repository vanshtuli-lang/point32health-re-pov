"""airflow-legacy-graph: v1
file: hp_lnappd064_dev_dxcg_rundxcg6all_rmr.graph.yaml
"""

from airflow.providers.standard.operators.bash import BashOperator
from airflow.sdk import DAG
from include.assets import autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_rmr
from pathlib import Path
from pendulum import DateTime, Time, Timezone
from pendulum.tz.timezone import FixedTimezone
import datetime

with DAG(
    dag_id="hp_lnappd064_dev_dxcg_rundxcg6all_rmr",
    schedule=[autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_rmr],
    start_date=DateTime(1970, 1, 1, 0, 0, 0),
    catchup=False,
    tags=["airflow-legacy:graph-v1"],
    default_args={"owner": "dxcgusr", "queue": "lnappd064"},
    doc_md=Path(__file__)
    .parent.parent.joinpath("include/hp_lnappd064_dev_dxcg_rundxcg6all_rmr/_dag.md")
    .read_text(),
) as dag:
    hp_lnappd064_dev_dxcg_rundxcg6all_rmr_task = BashOperator(
        task_id="hp_lnappd064_dev_dxcg_rundxcg6all_rmr",
        doc_md=Path(__file__)
        .parent.parent.joinpath(
            "include/hp_lnappd064_dev_dxcg_rundxcg6all_rmr/hp_lnappd064_dev_dxcg_rundxcg6all_rmr.md"
        )
        .read_text(),
        queue="lnappd064",
        bash_command="source /app/dxcg/DXCG6ALL/scripts/setenv.sh; /app/dxcg/DXCG6ALL/scripts/rundxcg6all devl dxcg6all_DxCG_6.4_comm_rarx rmr > /app/dxcg/DXCG6ALL/log/RUNDXCG6ALL_RMR.log 2> /app/dxcg/DXCG6ALL/log/RUNDXCG6ALL_RMR.err",
        doc="Run DxCG RiskSolutions v6 for configuration dxcg6all_DxCG_6.4_comm_rarx",
        owner="dxcgusr",
    )
