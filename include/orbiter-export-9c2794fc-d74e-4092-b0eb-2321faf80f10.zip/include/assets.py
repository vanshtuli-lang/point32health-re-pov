"""Asset definitions with AssetWatcher triggers.

Each Asset has an AssetWatcher with a trigger that monitors a
condition. Consumer DAGs can schedule on these assets using
schedule=[asset_name]."""

from airflow.sdk.definitions.asset import Asset, AssetWatcher
from airflow_autosys.trigger import TaskConditionTrigger

autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_mrm = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_mrm",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_mrm_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_MPM)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_lnappd064_dev_dxcg_rundxcg6all_mpm",
                        "task_id": "hp_lnappd064_dev_dxcg_rundxcg6all_mpm",
                        "job_name": "HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_MPM",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_mrm",
            ),
        )
    ],
)
autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_mpm = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_mpm",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_mpm_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_RMR)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_lnappd064_dev_dxcg_rundxcg6all_rmr",
                        "task_id": "hp_lnappd064_dev_dxcg_rundxcg6all_rmr",
                        "job_name": "HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_RMR",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_mpm",
            ),
        )
    ],
)
autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_rmr = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_rmr",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_rmr_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_RMO)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_lnappd064_dev_dxcg_rundxcg6all_rmo",
                        "task_id": "hp_lnappd064_dev_dxcg_rundxcg6all_rmo",
                        "job_name": "HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_RMO",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_rmr",
            ),
        )
    ],
)
autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_rmo = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_rmo",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_rmo_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_PMR)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_lnappd064_dev_dxcg_rundxcg6all_pmr",
                        "task_id": "hp_lnappd064_dev_dxcg_rundxcg6all_pmr",
                        "job_name": "HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_PMR",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_rmo",
            ),
        )
    ],
)
autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_pmr = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_pmr",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_pmr_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_PMO)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_lnappd064_dev_dxcg_rundxcg6all_pmo",
                        "task_id": "hp_lnappd064_dev_dxcg_rundxcg6all_pmo",
                        "job_name": "HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_PMO",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_pmr",
            ),
        )
    ],
)
autosys_conditionlocalhp_lnappd064_dev_dxcg_rundxcg6all_pmo = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_pmo",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_pmo_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.LNAPPD064.DEV.DXCG_GET_EDW_EXTRACTS6ALL)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_lnappd064_dev_dxcg_get_edw_extracts6all",
                        "task_id": "hp_lnappd064_dev_dxcg_get_edw_extracts6all",
                        "job_name": "HP.LNAPPD064.DEV.DXCG_GET_EDW_EXTRACTS6ALL",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_rundxcg6all_pmo",
            ),
        )
    ],
)
autosys_conditionlocalhp_lnappd064_dev_dxcg_get_edw_extracts6all = Asset(
    name="autosys-condition://local/hp_lnappd064_dev_dxcg_get_edw_extracts6all",
    watchers=[
        AssetWatcher(
            name="autosys-condition://local/hp_lnappd064_dev_dxcg_get_edw_extracts6all_watcher",
            trigger=TaskConditionTrigger(
                condition="s(HP.AZLXDSD01.DEV.EDWINF_DX_M_DXCG6ALL_MAIN1_END_GK)",
                condition_ast=[
                    {
                        "type": "status",
                        "status": "success",
                        "dag_id": "hp_azlxdsd01_dev_edwinf_dx_m_dxcg6all_main1_end_gk",
                        "task_id": "hp_azlxdsd01_dev_edwinf_dx_m_dxcg6all_main1_end_gk",
                        "job_name": "HP.AZLXDSD01.DEV.EDWINF_DX_M_DXCG6ALL_MAIN1_END_GK",
                        "instance": None,
                        "lookback_hours": None,
                        "scope": "external",
                    }
                ],
                asset_name="autosys-condition://local/hp_lnappd064_dev_dxcg_get_edw_extracts6all",
            ),
        )
    ],
)
