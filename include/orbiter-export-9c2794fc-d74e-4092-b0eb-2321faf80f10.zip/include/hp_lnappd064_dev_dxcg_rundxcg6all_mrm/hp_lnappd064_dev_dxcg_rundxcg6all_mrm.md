## HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_MRM

**Original Source Type:** AutoSys CMD Job

---

**AutoSys Source Info**

- **Machine:** lnappd064
- **Description:** Run DxCG RiskSolutions v6 for configuration dxcg6all_DxCG_6.4_medr_ra
- **Owner:** dxcgusr