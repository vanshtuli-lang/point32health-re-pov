## HP.LNAPPD064.DEV.DXCG_RUNDXCG6ALL_RMO

**Original Source Type:** AutoSys CMD Job

---

**AutoSys Source Info**

- **Description:** Run DxCG RiskSolutions v6 for configuration dxcg6all_DxCG_6.4_comm_raam
- **Owner:** dxcgusr

---

**No schedule resolved**

The translator could not derive a schedule from the source system.
The DAG is manual-trigger only. Sources checked:

- no run_calendar attribute
- date_conditions=0 (date-based scheduling disabled)
- auto_delete not set (no @once schedule)