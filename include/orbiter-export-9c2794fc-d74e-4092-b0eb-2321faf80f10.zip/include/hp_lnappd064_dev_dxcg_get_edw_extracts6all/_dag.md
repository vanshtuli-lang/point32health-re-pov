## HP.LNAPPD064.DEV.DXCG_GET_EDW_EXTRACTS6ALL

**Original Source Type:** AutoSys CMD Job

---

**AutoSys Source Info**

- **Description:** Get edw extracts
- **Owner:** dxcgusr

---

**No schedule resolved**

The translator could not derive a schedule from the source system.
The DAG is manual-trigger only. Sources checked:

- no run_calendar attribute
- date_conditions=0 (date-based scheduling disabled)
- auto_delete not set (no @once schedule)