## HP.LNAPPD064.DEV.DXCG_GET_EDW_EXTRACTS6ALL

**Original Source Type:** AutoSys CMD Job

---

**AutoSys Source Info**

- **Machine:** lnappd064
- **Description:** Get edw extracts
- **Owner:** dxcgusr